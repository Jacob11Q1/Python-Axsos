from django.apps import AppConfig


class TimeDisplayConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'time_display'
