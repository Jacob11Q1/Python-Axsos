# modularizing/child.py
import parent

print("Namespace inside child.py:", locals())

print("Now we are inside child.py")